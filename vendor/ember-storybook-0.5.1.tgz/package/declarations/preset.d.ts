import { type StorybookConfigVite } from '@storybook/builder-vite';
import type { StorybookConfig } from './types';
import type { PresetProperty } from 'storybook/internal/types';
export declare const previewAnnotations: PresetProperty<'previewAnnotations'>;
export declare const managerEntries: (entries?: string[]) => string[];
export declare const viteFinal: StorybookConfigVite['viteFinal'];
export declare const experimental_indexers: StorybookConfig['experimental_indexers'];
export declare const core: PresetProperty<'core'>;
//# sourceMappingURL=preset.d.ts.map