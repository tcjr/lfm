import type { EmberRenderer, StoryContext } from './types';
import type { ArgsStoryFn, RenderContext } from 'storybook/internal/types';
export declare const render: ArgsStoryFn<EmberRenderer>;
export declare function renderToCanvas({ storyFn, showMain, storyContext, forceRemount }: RenderContext<EmberRenderer> & {
    storyContext: StoryContext;
}, canvasElement: EmberRenderer['canvasElement']): Promise<() => void>;
//# sourceMappingURL=render.d.ts.map