import type { RouteParameters } from './types';
type Args = Record<string, unknown>;
/**
 * Structural shapes of `@ember/application` and `@ember/application/instance`.
 * Used so the resolver can be unit tested without importing Ember at runtime.
 */
export interface ApplicationClass {
    prototype: object;
    create(options?: Record<string, unknown>): {
        buildInstance(): object;
    };
}
export type ApplicationInstanceClass = new (...args: never[]) => object;
/**
 * The result of the framework's default `render` function.
 *
 * Storybook's decorator pipeline delivers the (possibly decorator-transformed)
 * args to `render` via `originalStoryFn(args, context)` — but nothing else. To
 * make those args reach `renderToCanvas`, `render` reports them back alongside
 * the component instead of returning a bare component.
 *
 * `route` rides along the same way: it is the only channel by which a story
 * rendered through `<RenderStory>` (which never sees the story context) can learn
 * it is a route story.
 */
export interface EmberStoryResult {
    component: object;
    args: Args;
    route?: RouteParameters;
}
export declare function isEmberStoryResult(value: unknown): value is EmberStoryResult;
/**
 * Normalizes whatever `storyFn()` returned into `{ component, args }`.
 *
 * - A story rendered through the framework's `render` returns an `EmberStoryResult`
 *   whose `args` are the final (decorated) args.
 * - A story with its own `render` (e.g. a template) returns the component/template
 *   directly; in that case the args are the raw `fallbackArgs` (the story already
 *   captured what it needs).
 */
export declare function normalizeStoryResult(result: unknown, fallbackArgs: Args): {
    component: object;
    args: Args;
    route?: RouteParameters;
};
export declare function createAppResolver(params: {
    application: ApplicationClass;
    applicationInstance: ApplicationInstanceClass;
}): (appOption: unknown, opts: {
    rootElement: HTMLElement;
}) => object;
export {};
//# sourceMappingURL=story-result.d.ts.map