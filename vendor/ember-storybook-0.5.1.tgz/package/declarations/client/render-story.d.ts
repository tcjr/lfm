import Component from '@glimmer/component';
interface RenderStorySignature {
    Args: {
        story: () => object;
        args: Record<string, unknown>;
    };
    Element: HTMLDivElement;
}
export declare class RenderStory extends Component<RenderStorySignature> {
    render: import("ember-modifier").FunctionBasedModifier<{
        Args: {
            Positional: unknown[];
            Named: import("ember-modifier/-private/signature").EmptyObject;
        };
        Element: HTMLDivElement;
    }>;
}
export {};
//# sourceMappingURL=render-story.d.ts.map