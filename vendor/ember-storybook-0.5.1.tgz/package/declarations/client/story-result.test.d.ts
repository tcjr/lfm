export {};
//# sourceMappingURL=story-result.test.d.ts.map