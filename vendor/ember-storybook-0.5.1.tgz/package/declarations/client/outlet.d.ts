import type { OutletMode, RouteParameters } from './types';
import type ApplicationInstance from '@ember/application/instance';
import type { ComponentLike } from '@glint/template';
/**
 * What Ember's outlet root hands a route template on the classic backend. A
 * route template is *not* a component story: it receives exactly `@model` and
 * `@controller` (`OUTLET_COMPONENT_TEMPLATE` in ember-source); its `{{outlet}}`
 * reads the child from the state chain below, not from an argument.
 */
export interface OutletRenderState {
    owner: object;
    name: string;
    controller: unknown;
    model: unknown;
    template: object;
}
/**
 * Mirrors ember-source's internal `OutletState`. The shape is structural, not
 * nominal, so a plain object is accepted by `setOutletState`; the leaf's
 * `outlets.main` is what a nested `{{outlet}}` reads.
 */
export interface OutletState {
    render: OutletRenderState;
    outlets: {
        main: OutletState | undefined;
    };
}
export interface RouteStoryInput {
    /** The route template — the story's `component`. */
    template: object;
    /** `parameters.ember.route`. */
    route: RouteParameters;
    /**
     * What the outlet renders — see {@link resolveOutletStub}. `null` leaves the
     * outlet as a hole.
     */
    outlet?: ComponentLike | null;
    /** Final (decorated) story args; `model`/`controller` feed the route. */
    args: Record<string, unknown>;
    /** Story name, used when `route.name` is not given. */
    storyName: string;
    /** The booted app instance the route renders under. */
    owner: object;
}
export interface OutletResolveInput {
    /** `parameters.ember.route` of the story being rendered. */
    route: RouteParameters;
    /** Value of the `outlet` global (see `src/outlet-key.ts`), if any. */
    mode?: OutletMode;
    /**
     * The component rendered when the global asks for a visible placeholder.
     * Called lazily (and so may be an async chunk load) and only when needed;
     * injected so this module stays free of Ember-owned template components.
     */
    placeholder: () => ComponentLike | Promise<ComponentLike>;
}
/**
 * Decides what `{{outlet}}` renders, parsing `parameters.ember.route.outlet` at
 * the boundary. Returns the component for the outlet position — curried, see
 * {@link curryOutlet} — or `null` for a hole.
 *
 * An explicit `route.outlet` is author intent and always wins, so a story stays
 * deterministic no matter how the toolbar is set:
 *
 * - a `string` labels the placeholder (`outlet: 'settings'`);
 * - a component renders in the outlet position (`outlet: MyOutlet` — classes,
 *   template-only components and inline `<template>`s; template-only ones are
 *   plain objects, so "not the retired `{ template, ... }` bag" is the runtime
 *   discriminator).
 *
 * otherwise the global decides: `placeholder` renders the injected marker,
 * anything else leaves a hole.
 */
export declare function resolveOutletStub({ route, mode, placeholder }: OutletResolveInput): Promise<ComponentLike | null>;
/**
 * Whether the component's *own* template references `{{outlet}}` — i.e. it is a
 * route template, which is how an unannotated route-story is recognized (#62).
 *
 * A template factory caches a per-owner (plus ownerless) `TemplateImpl`; its
 * `parsedLayout.block` is the parsed wire-format tuple
 * `[statements, locals, upvars]`. Which slot reveals the outlet depends on the
 * compiler that produced the template — the app's ember-source:
 *
 * - classic (`< 7.5.0`): the keyword `-outlet` is a free name, so
 *   every use of `{{outlet}}` — and only uses of it — lands in `upvars`;
 *   checking that slot cannot mistake a string literal `"-outlet"` used as an
 *   argument for a real outlet.
 * - RFC 1099 route rendering (`>= 7.5.0`): `{{outlet}}` compiles to the
 *   template's own `@outlet` argument — `{{component (-outlet @outlet)}}` —
 *   which lands in `locals` (strict-mode templates list their arguments there).
 */
export declare function templateUsesOutlet(component: object): boolean;
/**
 * Builds the `OutletState` for a route story — the outlet-root backend, used on
 * Ember builds that still have `view:-outlet` (see {@link outletRootSupported}).
 *
 * `{{outlet}}` compiles to the `-outlet` keyword, which reads its child from
 * Glimmer's *dynamic scope*, which `renderComponent` never populates — so route
 * templates are rendered through Ember's own outlet root instead, and this is
 * the state handed to it. Leaving `outlets.main` undefined is what makes
 * `{{outlet}}` render a hole.
 */
export declare function buildRouteOutletState({ template: routeTemplate, route, outlet, args, storyName, owner }: RouteStoryInput): OutletState;
/**
 * Ember's `OutletView` (the router's top-level view), reduced to the surface
 * this module drives. It is only reachable through the container, so the type is
 * declared here rather than imported from `@ember/-internals`.
 */
export interface OutletView {
    appendTo(target: HTMLElement): void;
    setOutletState(state: OutletState): void;
}
/**
 * Whether this Ember build still hosts `{{outlet}}` in the classic outlet root.
 *
 * Until ember-source 7.5.0 the router always registered `view:-outlet`; RFC
 * 1099 route rendering (implemented across emberjs/ember.js#21460 and its
 * series) deleted the view, the `template:-outlet` and the classic `-outlet`
 * keyword outright. The container entry is the switch between the backends
 * that have a classic outlet root and those that have not — version strings
 * are unreliable across pre-releases, the container probe is not.
 */
export declare function outletRootSupported(owner: object): boolean;
/**
 * Whether `{{outlet}}` on this build must be resolved through the router's
 * renderer.
 *
 * ember-source 7.5.0 completed RFC 1099 route rendering (emberjs/ember.js
 * #21460) and compiled `{{outlet}}` back into a keyword:
 * `{{component (-outlet @outlet)}}`, the template's own `@outlet` argument
 * wrapped in a call to the `-outlet` keyword helper, which only ember's
 * router-backed resolver (`RouterResolver`, reachable through the container's
 * `renderer:-dom`) knows. The base resolver `renderComponent` builds for an
 * owner that never rendered a root asserts: "The `{{outlet}}` keyword requires
 * the router, which is not available here." Classic builds (before 7.5.0) host
 * `{{outlet}}` in the outlet root instead; {@link outletRootSupported} selects
 * that backend for those.
 *
 * The probe — no classic outlet root, but a root-render hook to install the
 * router's renderer with — never reads the version; builds that would resolve
 * `{{outlet}}` either way are primed too, and priming is harmless: the
 * router's resolver resolves everything the base one does.
 */
export declare function routerRendererPrimingSupported(application: object): boolean;
/**
 * Installs the router's renderer for a booted app instance: one render of an
 * empty root through {@link RootRenderableInstance.renderRootComponent} — the
 * same call Ember's `Router` makes when it first paints. A Storybook app
 * boots but never routes, so without this `renderComponent` builds its own
 * router-less renderer for the owner and route stories hit the keyword
 * assert on ember-source >= 7.5.0 builds.
 *
 * Called from `bootApp` *before the first story render*, because Ember keeps
 * exactly one renderer per owner (`RENDERER_FOR_OWNER`) — installing a second
 * one while the strict renderer has live roots recreates the corrupted
 * opcode-table crashes of #27/#33.
 *
 * The empty root targets a cursor inside `rootElement`, so Ember does not
 * clear the canvas, and a later root render (the app's own router, say)
 * replaces it. Teardown is the app's: the renderer is destroyable with its
 * owner — the same lifecycle the classic outlet root had.
 */
export declare function primeRouterRenderer(application: object): void;
/**
 * Renders `state` into `element` through Ember's outlet root and waits for the
 * render to settle.
 */
export declare function mountOutletView(application: ApplicationInstance, state: OutletState, element: HTMLElement): Promise<OutletView>;
/**
 * Swaps what the outlet renders, in place. This is how the router updates a live
 * route tree, so arg changes do not tear the route's components down.
 */
export declare function updateOutletView(view: OutletView, state: OutletState): Promise<void>;
//# sourceMappingURL=outlet.d.ts.map