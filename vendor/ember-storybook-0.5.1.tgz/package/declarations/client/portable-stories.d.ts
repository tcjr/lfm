import type { EmberRenderer } from './types';
import type { NamedOrDefaultProjectAnnotations, NormalizedProjectAnnotations } from 'storybook/internal/types';
/**
 * Function that sets the globalConfig of your storybook. The global config is the preview module of
 * your .storybook folder.
 *
 * It should be run a single time, so that your global config (e.g. decorators) is applied to your
 * stories when using `composeStories` or `composeStory`.
 *
 * Example:
 *
 * ```jsx
 * // setup-file.js
 * import { setProjectAnnotations } from '@storybook/preact';
 * import projectAnnotations from './.storybook/preview';
 *
 * setProjectAnnotations(projectAnnotations);
 * ```
 *
 * @param projectAnnotations - E.g. (import projectAnnotations from '../.storybook/preview')
 */
export declare function setProjectAnnotations(projectAnnotations: NamedOrDefaultProjectAnnotations<EmberRenderer> | NamedOrDefaultProjectAnnotations<EmberRenderer>[]): NormalizedProjectAnnotations<EmberRenderer>;
//# sourceMappingURL=portable-stories.d.ts.map