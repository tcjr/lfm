export declare function ElementBlock({ element }: {
    element: string;
}): import("react").FunctionComponentElement<{
    theme?: import("storybook/theming").Theme;
    as?: React.ElementType;
} & import("react").ClassAttributes<HTMLDivElement> & import("react").HTMLAttributes<HTMLDivElement>> | undefined;
//# sourceMappingURL=element.d.ts.map