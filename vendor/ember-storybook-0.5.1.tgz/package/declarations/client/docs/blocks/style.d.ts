import { type Entry } from './ui';
export declare function PartsTable({ entries }: {
    entries: Entry[];
}): import("react").FunctionComponentElement<{
    theme?: import("storybook/theming").Theme;
    as?: React.ElementType;
} & import("react").ClassAttributes<HTMLTableElement> & import("react").TableHTMLAttributes<HTMLTableElement>>;
export declare function CssPropertiesTable({ entries }: {
    entries: Entry[];
}): import("react").FunctionComponentElement<{
    theme?: import("storybook/theming").Theme;
    as?: React.ElementType;
} & import("react").ClassAttributes<HTMLTableElement> & import("react").TableHTMLAttributes<HTMLTableElement>>;
//# sourceMappingURL=style.d.ts.map