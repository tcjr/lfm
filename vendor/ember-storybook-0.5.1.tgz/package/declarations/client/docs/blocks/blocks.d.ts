import type { EmberMeta } from '../../../node/types';
import type { BlockInfo } from 'ember-docgen';
export declare const ParamType: import("storybook/theming").StyledComponent<{
    theme?: import("storybook/theming").Theme;
    as?: React.ElementType;
}, import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, {}>;
export declare const ParamRow: import("storybook/theming").StyledComponent<{
    theme?: import("storybook/theming").Theme;
    as?: React.ElementType;
}, import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, {}>;
export declare function BlocksTable({ blocks, subcomponentNames, data }: {
    blocks: Record<string, BlockInfo>;
    subcomponentNames: Set<string>;
    data?: EmberMeta;
}): import("react").FunctionComponentElement<{
    theme?: import("storybook/theming").Theme;
    as?: React.ElementType;
} & import("react").ClassAttributes<HTMLTableElement> & import("react").TableHTMLAttributes<HTMLTableElement>> | undefined;
export declare function BlocksSection({ blocks, subcomponentNames, data }: {
    blocks: Record<string, BlockInfo>;
    subcomponentNames: Set<string>;
    data?: EmberMeta;
}): import("react").FunctionComponentElement<{
    theme?: import("storybook/theming").Theme;
    as?: React.ElementType;
} & import("react").ClassAttributes<HTMLDivElement> & import("react").HTMLAttributes<HTMLDivElement>>;
//# sourceMappingURL=blocks.d.ts.map