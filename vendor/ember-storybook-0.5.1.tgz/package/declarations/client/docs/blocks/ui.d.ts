import { type Theme } from 'storybook/theming';
export interface Entry {
    name: string;
    description?: string;
}
export declare function isHtmlElement(name: string): boolean;
export declare const TableWrapper: import("storybook/theming").StyledComponent<{
    theme?: Theme;
    as?: React.ElementType;
}, import("react").DetailedHTMLProps<import("react").TableHTMLAttributes<HTMLTableElement>, HTMLTableElement>, {}>;
export declare function renderHead(columns: string[]): import("react").DetailedReactHTMLElement<{
    className: string;
}, HTMLElement>;
export declare function renderBody(entries: Entry[]): import("react").DetailedReactHTMLElement<{
    className: string;
}, HTMLElement>;
export declare const H2: import("storybook/theming").StyledComponent<import("@storybook/addon-docs/blocks").HeadingProps & {
    children?: import("react").ReactNode | undefined;
} & {
    theme?: Theme;
}, {}, {}>;
//# sourceMappingURL=ui.d.ts.map