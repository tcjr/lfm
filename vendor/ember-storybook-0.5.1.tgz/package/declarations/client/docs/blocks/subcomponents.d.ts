import type { EmberMeta } from '../../../node/types';
import type { SubcomponentRef } from '../signature';
export declare function SubcomponentsArea({ components, data }: {
    components: SubcomponentRef[];
    data?: EmberMeta;
}): import("react").FunctionComponentElement<{
    theme?: import("storybook/theming").Theme;
    as?: React.ElementType;
} & import("react").ClassAttributes<HTMLDivElement> & import("react").HTMLAttributes<HTMLDivElement>> | undefined;
//# sourceMappingURL=subcomponents.d.ts.map