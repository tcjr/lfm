import { DocsRenderer } from './renderer';
export declare const parameters: {
    docs: {
        renderer: () => Promise<DocsRenderer>;
    };
};
//# sourceMappingURL=preview-patch.d.ts.map