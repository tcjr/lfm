import type { ComponentSignature } from 'ember-docgen';
export declare function buildArgTypes(sig: ComponentSignature): Record<string, unknown>;
/**
 * Merges signature-derived argTypes with the story-provided argTypes.
 *
 * Signature argTypes are the base; story argTypes enhance them for better
 * rendering (custom `name`, `control`, `options`, ...). For args present in
 * both, story fields win — but only when they carry an actual value, so an
 * explicit `undefined` never masks a signature field. The signature keeps the
 * `table` and `description` the story does not override.
 *
 * The `type` object is deep-merged: a story-provided partial `type` (e.g.
 * `type: 'string'`) keeps the signature's `required` flag unless the story
 * explicitly sets it, while the story's `type.name` still wins.
 *
 * Key order is meaningful: story-provided keys come first in the order the
 * user defined them (user intent wins), followed by the remaining
 * signature-derived keys in declaration order. Alphabetising is a display
 * concern handled by Storybook itself (`parameters.controls.sort` for the
 * panel, `parameters.docs.controls.sort` for the docs Controls block).
 */
export declare function mergeArgTypes(signatureArgTypes: Record<string, unknown>, storyArgTypes: Record<string, unknown>): Record<string, unknown>;
/**
 * Whether the docs page should render the Args/controls table: either the
 * component signature exposes args, or the meta carries story-provided
 * argTypes (e.g. for a template-only component with story argTypes but no
 * signature args).
 */
export declare function shouldShowArgsSection(sig: ComponentSignature, metaArgTypes?: Record<string, unknown>): boolean;
//# sourceMappingURL=extractArgTypes.d.ts.map