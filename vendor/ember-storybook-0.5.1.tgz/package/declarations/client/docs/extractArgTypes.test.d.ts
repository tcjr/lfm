export {};
//# sourceMappingURL=extractArgTypes.test.d.ts.map