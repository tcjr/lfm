import type { Parameters } from 'storybook/internal/types';
export { argTypesEnhancers, decorators } from './annotations';
export declare const parameters: Parameters;
//# sourceMappingURL=config.d.ts.map