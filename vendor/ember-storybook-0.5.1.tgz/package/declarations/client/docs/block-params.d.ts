import type { BlockInfo, BlockParam } from 'ember-docgen';
/**
 * Unwrap the params union to plain block params at the yield surface: a
 * yield hash expands to its named entries, but unfolded named types
 * (`nested`) are not descended into. Use for anything reflecting what the
 * block actually receives (e.g. slot bindings).
 */
export declare function unwrapBlockParamsShallow(params: BlockInfo['params']): BlockParam[];
/**
 * Unwrap every block param: yield hashes expand to their named entries and
 * unfolded named types descend into all members — the whole param tree. Use
 * wherever every referenced component must be found (subcomponent
 * collection, ref rewriting).
 */
export declare function unwrapBlockParams(params: BlockInfo['params']): BlockParam[];
//# sourceMappingURL=block-params.d.ts.map