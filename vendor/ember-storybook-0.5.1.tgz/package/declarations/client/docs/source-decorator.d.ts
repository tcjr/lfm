import type { EmberRenderer } from '../types';
import type { ComponentSignature } from 'ember-docgen';
import type { Args, ArgTypes, DecoratorFunction } from 'storybook/internal/types';
export declare function toArgument(key: string, value: unknown, argTypes: ArgTypes): string | undefined;
export declare function generateBlockSourceCode(sig: ComponentSignature, args: Args, indent: string): string;
export declare function resolveTemplateArgs(template: string, args: Args): string;
export declare function generateSource(component: {
    name?: string;
}, args: Args, argTypes: ArgTypes, storyId?: string): string | undefined;
export declare const sourceDecorator: DecoratorFunction<EmberRenderer>;
//# sourceMappingURL=source-decorator.d.ts.map