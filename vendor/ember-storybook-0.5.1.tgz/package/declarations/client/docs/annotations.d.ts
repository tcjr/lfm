import type { EmberRenderer } from '../types';
import type { DecoratorFunction, Parameters, StoryContextForEnhancers, StrictArgTypes } from 'storybook/internal/types';
export declare const argTypesEnhancers: ((context: StoryContextForEnhancers<EmberRenderer>) => StrictArgTypes)[];
export declare const parameters: Parameters;
export declare const decorators: DecoratorFunction<EmberRenderer>[];
//# sourceMappingURL=annotations.d.ts.map