export default function Page(): import("react").FunctionComponentElement<import("react").FragmentProps>;
//# sourceMappingURL=page.d.ts.map