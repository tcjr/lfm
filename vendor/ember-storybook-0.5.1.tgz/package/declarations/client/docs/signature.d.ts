import type { EmberMeta } from '../../node/types';
import type { BlockInfo, BlockParam, ComponentSignature } from 'ember-docgen';
/**
 * Key used for default exports in signature/component maps. Mirrors
 * ember-docgen's `Default` sentinel — duplicated as a literal so client
 * code does not pull ember-docgen's node-only dependencies into the bundle.
 */
export declare const DEFAULT_EXPORT = "__DEFAULT__";
export interface SubcomponentRef {
    name: string;
    signature?: ComponentSignature;
    importPath?: string;
}
export declare function componentDisplayName(ref: undefined | {
    filePath?: string;
    exportName?: string;
}, data: EmberMeta): string | undefined;
export declare function applyModifiers(signature: ComponentSignature, modifiers?: {
    name: string;
    typeArgs: string[];
}[]): ComponentSignature;
/**
 * The name a yielded component goes by in the docs page's Subcomponents and
 * Blocks table: its own name, else its yield key. Local components (not
 * exported) are named by the yield key — the declaration name is an
 * implementation detail.
 */
export declare function subcomponentName(param: BlockParam, data: EmberMeta): string;
export declare function collectSubcomponents(blocks: Record<string, BlockInfo>, data: EmberMeta): SubcomponentRef[];
//# sourceMappingURL=signature.d.ts.map