import type { DocsContextProps } from 'storybook/internal/types';
export declare class DocsRenderer {
    render: (context: DocsContextProps, docsParameter: {
        components?: Record<string, unknown>;
    }, element: HTMLElement) => Promise<void>;
    unmount: (element: HTMLElement) => void;
}
//# sourceMappingURL=renderer.d.ts.map