export default function emberStorybookDocsAddon(): import("storybook/internal/csf").PreviewAddon<import("storybook/internal/csf").AddonTypes>;
//# sourceMappingURL=addon-preview.d.ts.map