export {};
//# sourceMappingURL=vite-plugin.test.d.ts.map