import { type ContributorAPI } from '../vite-plugin-orchestrator';
import type { Plugin } from 'vite';
export interface ComponentMeta {
    file?: string;
    signatureName?: string;
    name?: string;
}
export declare function metaContributor(api: ContributorAPI): Plugin;
//# sourceMappingURL=vite-plugin.d.ts.map