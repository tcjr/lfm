import { type StaticMeta, type StaticStory } from 'storybook/internal/csf-tools';
import { type ExportedName } from './shared';
import type { Program } from 'oxc-parser';
/**
 * A map with contents of a component file:
 *
 * - `key`: The component name in the file
 * - `value`:
 *   - `string`: The exported component name
 *   - `undefined`: Not exported
 *   - `Default`: default export
 */
export type ComponentMap = Record<ExportedName, string>;
export declare function readAndPreprocess(filePath: string): {
    rawCode: string;
    processedCode: string;
};
export declare function parseProcessedCode(processedCode: string, filePath: string): Program;
/**
 * Result of parsing a story file, covering all subsystem needs.
 */
export interface StoryFile {
    meta: StaticMeta;
    component: {
        /**
         * Project-relative path to the component file.
         * Set only when the component is imported from a local module.
         */
        file?: string;
        /**
         * The key to look up the component's signature in the component
         * file's signatures record. Matches TypeDoc's deriveComponentName.
         *
         * - `"Greeting"` for `export const Greeting = ...`
         * - `"Card"` for `export { Card as CardExport }`
         * - `"Button"` for `export default class Button ...`
         */
        signatureName?: string;
        /**
         * The name used to invoke the component in generated source.
         * Differs from `signatureName` for default exports, where the
         * signature is keyed by the `__DEFAULT__` sentinel but the real
         * component name (e.g. `"Button"`) is known from the component file.
         */
        name?: string;
    };
    stories: (StaticStory & {
        inlineTemplate?: string;
    })[];
}
/**
 * Parse a component file and return a map of all declarations.
 *
 * Each key is the internal variable/class name, each value is:
 * - `string` for named exports (the export name)
 * - `Default` for `export default`
 * - `undefined` for non-exported declarations
 */
export declare function parseComponentFile(compPath: string): ComponentMap | undefined;
/**
 * Parse a story file and return metadata about the component it references,
 * including template sources for each named story export.
 */
export declare function parseStoryFile(storyPath: string): StoryFile | undefined;
//# sourceMappingURL=parser.d.ts.map