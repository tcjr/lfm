import type { StoryFilePath } from './types';
export declare const PROJECT_ROOT: string;
export { Default } from 'ember-docgen';
export type ExportedName = string;
export declare function normalizeFilePath(absPath: string): string;
export declare function addStoryFileListener(listener: (filePath: string) => void): () => void;
export declare function registerStoryFile(filePath: string): void;
export declare function getStoryFiles(): StoryFilePath[];
export declare function isStoryFile(filePath: string): boolean;
export declare function isComponentFile(filePath: string): boolean;
//# sourceMappingURL=shared.d.ts.map