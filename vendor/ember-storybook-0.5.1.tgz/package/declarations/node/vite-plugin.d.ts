import type { Plugin } from 'vite';
export interface EmberStorybookPluginOptions {
    /**
     * Resolves once Storybook has indexed the stories, which is what registers
     * the story files (see `emberIndexer`).
     */
    waitForStoryIndex?: () => Promise<unknown>;
}
export declare function emberStorybookPlugin(options?: EmberStorybookPluginOptions): Plugin[];
//# sourceMappingURL=vite-plugin.d.ts.map