import type { ComponentSignatureMap } from 'ember-docgen';
export declare function runTypeDoc(entryPoints: string[]): Promise<ComponentSignatureMap>;
//# sourceMappingURL=docgen.d.ts.map