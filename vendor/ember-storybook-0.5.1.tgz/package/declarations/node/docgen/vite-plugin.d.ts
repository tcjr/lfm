import { type ContributorAPI } from '../vite-plugin-orchestrator';
import type { Plugin } from 'vite';
export declare function signaturesContributor(api: ContributorAPI): Plugin;
//# sourceMappingURL=vite-plugin.d.ts.map