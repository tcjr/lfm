import type { StorybookConfig } from '../types';
export declare function defineMain(config: StorybookConfig): StorybookConfig;
export { type StorybookConfig } from '../types';
//# sourceMappingURL=index.d.ts.map