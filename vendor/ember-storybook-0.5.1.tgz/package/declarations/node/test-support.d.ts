export declare function tempFixture(files: Record<string, string>): {
    base: string;
    [Symbol.dispose](): void;
};
//# sourceMappingURL=test-support.d.ts.map