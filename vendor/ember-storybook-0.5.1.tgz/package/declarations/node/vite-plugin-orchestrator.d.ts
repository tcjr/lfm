import type { Plugin } from 'vite';
export interface ContributorAPI {
    contribute(name: string, data: Record<string, unknown>): void;
    getContributions(): Map<string, Record<string, unknown>>;
    invalidate?: () => void;
    /**
     * Resolves once the story files are registered, i.e. once Storybook has
     * indexed them. Contributors await it before reading `getStoryFiles()`.
     */
    storyFilesReady(): Promise<void>;
}
export declare function emberStorybookVitePlugin(api: ContributorAPI): Plugin;
//# sourceMappingURL=vite-plugin-orchestrator.d.ts.map