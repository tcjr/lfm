import { type CsfOptions } from 'storybook/internal/csf-tools';
import type { Indexer } from 'storybook/internal/types';
export declare const readCsf: (fileName: string, options: CsfOptions) => Promise<import("storybook/internal/csf-tools").CsfFile>;
export declare const emberIndexer: Indexer;
//# sourceMappingURL=indexer.d.ts.map