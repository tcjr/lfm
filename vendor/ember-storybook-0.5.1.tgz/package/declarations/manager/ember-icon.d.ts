import type { SVGProps } from 'react';
export declare function EmberIcon(props: SVGProps<SVGSVGElement>): import("react").ReactSVGElement;
//# sourceMappingURL=ember-icon.d.ts.map